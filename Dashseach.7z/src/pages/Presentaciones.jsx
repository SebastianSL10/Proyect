import React, { useEffect, useState } from 'react';
import { GridComponent, Inject, Search, Page } from '@syncfusion/ej2-react-grids';
import { Header } from '../components';

const Presentaciones = ({ dataUpdated }) => {
  const [data, setData] = useState([]);

  const fetchData = () => {
      fetch('https://seach7.000webhostapp.com/api.php?apicall=readpresentacion')
        .then(response => response.json())
        .then(data => setData(data.contenido))
        .catch(error => console.log(error));
  };

  useEffect(() => {
    fetchData();  
  }, [dataUpdated]); // Agregar dataUpdated como dependencia  

  return (
    <div className="m-2 md:m-10 mt-24 p-2 md:p-10 bg-white rounded-3xl">
      <Header category="4" title="Presentaciones" />
      <GridComponent>
        <Inject services={[Search, Page]} />
        <div className="flex justify-end">
      <div className="w-2/3 p-4">
        <table className="border-collapse w-full border-blue-500">
          <thead>
            <tr className="bg-gray-200">
              <th className="py-2 px-4 border bg-blue-300">ID Presentación</th>
              <th className="py-2 px-4 border bg-blue-300">Nombre de la Presentación</th>
              <th className="py-2 px-4 border bg-blue-300">Acciones</th>
            </tr>
          </thead>
          <tbody className="border-blue-500">
            {Array.isArray(data) && data.length > 0 ? (
              data.map((item, index) => (
                <tr key={item.id_presentacion} className={index % 2 === 0 ? 'bg-gray-100' : ''}>
                  <td className="py-2 px-4 border">{item.id_presentacion}</td>
                  <td className="py-2 px-4 border">{item.nom_presentacion}</td>
                  <td className="py-2 px-4 border">
                    <button className="bg-yellow-500 text-white py-1 px-2 rounded mr-2" type="button">Editar</button>
                    <button className="bg-red-500 text-white py-1 px-2 rounded" type="button">Eliminar</button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="2">No hay datos disponibles</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
      </GridComponent>
    </div>
  );
};

export default Presentaciones;