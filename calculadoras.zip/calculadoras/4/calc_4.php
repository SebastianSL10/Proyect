<?php

    if(isset($_GET['calcular'])){
        $l= $_GET['Num1'];
        $m= $_GET['Num2'];
        $op= $_GET['calcular'];

        switch ($op) {
            case 'Sum': $result = $l + $m;
                break;
            case 'Rest': $result = $l - $m;
                break;
            case 'Mult': $result = $l * $m;
                break;    
            case 'Div': $result = $l / $m;
                break;
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculator Number Four</title>
</head>
<body>
    <h1> Calculadora #4</h1>
    <!--<form action=""></form>-->
    <form action="" method= "get">
        <!-- num 1-->
        <div>
            <label for="Num1">Number 1</label>
            <input type="number" name="Num1" value= <?php if(isset($l)) echo $l;?> id="Num1">
        </div>
        <!-- num 2-->
        <div>
            <br><label for="Num2">Number 2</label>
            <input type="number" name="Num2" value= <?php if(isset($m)) echo $m;?> id="Num2">
        </div>
        <!-- resultado-->
        <div>
            <br><label for="Result">Result</label>
            <input type="number" id="Result" value="<?= $result ?>" disabled>
        </div>
        <!-- operacion-->
        <br><select name="calcular"><br>
            <option value="Sum">Sumar</option>
            <option value="Rest">Restar</option>
            <option value="Mult">Multiplicar</option>
            <option value="Div">Dividir</option>

        </select><br><br>
        <input type="submit" value="Calcular"/>
    </form>
</body>
</html>