<?php
function recoge($var, $m = "")
{
    $tmp = is_array($m) ? [] : "";
    if (isset($_REQUEST[$var])) {
        if (!is_array($_REQUEST[$var]) && !is_array($m)) {
            $tmp = trim(htmlspecialchars($_REQUEST[$var]));
        } elseif (is_array($_REQUEST[$var]) && is_array($m)) {
            $tmp = $_REQUEST[$var];
            array_walk_recursive($tmp, function (&$valor) {
                $valor = trim(htmlspecialchars($valor));
            });
        }
    }
    return $tmp;
}

$segundos = recoge("segundos");

$segundosOk = false;

if ($segundos == "") {
    print "  <p class=\"aviso\">No ha escrito el número de segundos.</p>\n";
    print "\n";
} elseif (!ctype_digit($segundos)) {
    print "  <p class=\"aviso\">No ha escrito los segundos como número entero positivo.</p>\n";
    print "\n";
} else {
    $segundosOk = true;
}

if ($segundosOk) {
    $min = intdiv($segundos, 60);
    $seg = $segundos % 60;
    print "  <p>$segundos segundos son $min minutos y $seg segundos.</p>\n";
    print "\n";
}
?>