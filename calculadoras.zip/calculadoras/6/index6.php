
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>min-seg
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="mclibre-php-ejercicios.css" title="Color">
  <link rel="stylesheet" href="min-seg.php">
</head>

<body>
  <h1>Convertidor de segundos a minutos y segundos (Formulario)</h1>

  <form action="min-seg.php" method="get">
    <p>Escriba un número de segundos para convertir a minutos y segundos.</p>

    <p><label>Segundos: <input type="number" name="segundos" min="0"></label>

    <p>
      <input type="submit" value="Convertir">
      <input type="reset" value="Borrar">
    </p>
  </form>
</body>
</html>