<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <title>Bootstrap Example</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
  </head>
  <body class="p-3 m-0 border-0 bd-example">

<?php
$n1=$_POST["num1"];
$n2=$_POST["num2"];
echo "El número 1 es: ",$n1, "<br>";
echo "El número 2 es: ",$n2, "<br>";
echo "La suma es: ", $n1+$n2, "<br>";
echo "La resta es: ", $n1 - $n2, "<br>";
echo "La multiplicación es: ", $n1 * $n2, "<br>";
echo "La división es: ", $n1 / $n2, "<br>";
?>
<a class="btn btn-primary" href="index.html" role="button">Regresar</a>

</body>
</html>



