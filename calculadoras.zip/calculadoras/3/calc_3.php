<?php

    if(isset($_POST['operation'])){
        $x= $_POST['Num1'];
        $y= $_POST['Num2'];
        $op= $_POST['operation'];

        switch ($op) {
            case '+': $result = $x + $y;
                break;
            case '-': $result = $x - $y;
                break;
            case '*': $result = $x * $y;
                break;    
            case '÷': $result = $x / $y;
                break;
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculator Number Three</title>
</head>
<body>
    <h1>Calculadora #3</h1>
    <form action="" method= "post">
        <!-- num 1-->
        <div>
            <label for="Num1">Number 1</label>
            <input type="number" name="Num1" value= <?php if(isset($x)) echo $x;?> id="Num1">
        </div>
        <!-- num 2-->
        <div>
            <br><label for="Num2">Number 2</label>
            <input type="number" name="Num2" value= <?php if(isset($y)) echo $y;?> id="Num2">
        </div>
        <!-- resultado-->
        <div>
            <br><label for="Result">Result</label>
            <input type="number" id="Result" value="<?= $result ?>" disabled>
        </div>
        <!-- operacion-->
        <div>
            <br><input type="submit" value="+" name="operation">
            <input type="submit" value="-" name="operation">
            <input type="submit" value="*" name="operation">
            <input type="submit" value="÷" name="operation">
        </div>

    </form>
</body>
</html>